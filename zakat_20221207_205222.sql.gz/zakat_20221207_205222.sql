-- MySQL dump 10.13  Distrib 5.7.39, for Linux (x86_64)
--
-- Host: localhost    Database: zakat
-- ------------------------------------------------------
-- Server version	5.7.39-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_bank`
--

DROP TABLE IF EXISTS `tb_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pemilik` varchar(222) NOT NULL,
  `no_rek` varchar(111) NOT NULL,
  `nama_bank` varchar(222) NOT NULL,
  `foto` varchar(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_bank`
--

LOCK TABLES `tb_bank` WRITE;
/*!40000 ALTER TABLE `tb_bank` DISABLE KEYS */;
INSERT INTO `tb_bank` VALUES (1,'Fadilah Riczky','1111110000','BRI','Bank_Rakyat_Indonesia_(BRI).png'),(2,'Fadilah Riczky','0101010101010110','BSI','Bank_Syariah_Indonesia_svg.png');
/*!40000 ALTER TABLE `tb_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_berita`
--

DROP TABLE IF EXISTS `tb_berita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_berita` (
  `id_berita` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `slug` varchar(222) NOT NULL,
  `judul` varchar(222) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `konten` text NOT NULL,
  `thumbnail` varchar(222) NOT NULL,
  `waktu_buat` varchar(111) NOT NULL,
  `waktu_update` varchar(111) DEFAULT NULL,
  PRIMARY KEY (`id_berita`),
  KEY `id_user` (`id_user`),
  KEY `id_kategori` (`id_kategori`),
  CONSTRAINT `tb_berita_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `tb_kategori` (`id_kategori`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_berita`
--

LOCK TABLES `tb_berita` WRITE;
/*!40000 ALTER TABLE `tb_berita` DISABLE KEYS */;
INSERT INTO `tb_berita` VALUES (2,9917,'bantuan-cianjur1669786871.ppmnurba','Bantuan CIanjur',7,'<p>Berita tentang opensuse hari ini merupakan update yang memiliki beberapa fitur tambahan yang akan membantu para programer dalam meningkatkan produktifitas mereka.</p>','21482551.jpg','30-11-2022',NULL);
/*!40000 ALTER TABLE `tb_berita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_dokumentasi`
--

DROP TABLE IF EXISTS `tb_dokumentasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_dokumentasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(222) NOT NULL,
  `deskripsi` text NOT NULL,
  `foto` varchar(222) NOT NULL,
  `tanggal` varchar(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_dokumentasi`
--

LOCK TABLES `tb_dokumentasi` WRITE;
/*!40000 ALTER TABLE `tb_dokumentasi` DISABLE KEYS */;
INSERT INTO `tb_dokumentasi` VALUES (2,'Penyaluran Dana','ssssss','kimsohyun.jpg','23-11-2022'),(3,'Penyaluran Dana','ssssss','thumnbnail-install-aapanel.png','30-11-2022'),(4,'Korupsi Dana','Hiya hiya ','f202001261940131.jpg','25-11-2022');
/*!40000 ALTER TABLE `tb_dokumentasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_donasi`
--

DROP TABLE IF EXISTS `tb_donasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_donasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(222) DEFAULT NULL,
  `jumlah` int(100) DEFAULT NULL,
  `kategori` varchar(222) DEFAULT NULL,
  `keterangan` text,
  `tanggal` varchar(222) DEFAULT NULL,
  `telepon` varchar(222) DEFAULT NULL,
  `bank` varchar(222) DEFAULT NULL,
  `bukti_pembayaran` varchar(222) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_donasi`
--

LOCK TABLES `tb_donasi` WRITE;
/*!40000 ALTER TABLE `tb_donasi` DISABLE KEYS */;
INSERT INTO `tb_donasi` VALUES (1,'Jumadi',200000,'Pemasukan','ini donasi untuk umat','29-11-2022','','',''),(2,'Roni1',202002021,'Pengeluaran','Donasi topup mobile legend bagi yang membutuhkan1','19-11-2022','','',''),(3,NULL,1222222,'Pemasukan',NULL,'06-12-2022',NULL,NULL,'Bank_Syariah_Indonesia_svg1.png'),(4,'Fadilah Riczky',1222222,'Pemasukan','bismillah','06-12-2022','089673881528',NULL,'Bank_Syariah_Indonesia_svg2.png'),(5,'Fadilah Riczky',1222222,'Pemasukan','bismillah','06-12-2022','089673881528','BSI','Bank_Rakyat_Indonesia_(BRI)1.png');
/*!40000 ALTER TABLE `tb_donasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_kategori`
--

DROP TABLE IF EXISTS `tb_kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(222) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_kategori`
--

LOCK TABLES `tb_kategori` WRITE;
/*!40000 ALTER TABLE `tb_kategori` DISABLE KEYS */;
INSERT INTO `tb_kategori` VALUES (7,'Informasi','test');
/*!40000 ALTER TABLE `tb_kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_komentar`
--

DROP TABLE IF EXISTS `tb_komentar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_komentar` (
  `id_komentar` int(11) NOT NULL AUTO_INCREMENT,
  `id_berita` int(11) DEFAULT '0',
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `komentar` text,
  `waktu_buat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_komentar`),
  KEY `id_berita` (`id_berita`),
  CONSTRAINT `tb_komentar_ibfk_1` FOREIGN KEY (`id_berita`) REFERENCES `tb_berita` (`id_berita`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_komentar`
--

LOCK TABLES `tb_komentar` WRITE;
/*!40000 ALTER TABLE `tb_komentar` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_komentar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_layanan`
--

DROP TABLE IF EXISTS `tb_layanan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_layanan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(222) NOT NULL,
  `deskripsi` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_layanan`
--

LOCK TABLES `tb_layanan` WRITE;
/*!40000 ALTER TABLE `tb_layanan` DISABLE KEYS */;
INSERT INTO `tb_layanan` VALUES (1,'Jemput Sedekah1','Kami melayani bagi anda sekalian yang ingin sedekah namun terkendala ruang dan waktu.1'),(2,'Korupsi Sedekah','Kami juga melayani untuk melakukan korupsi sedekah demi kepentingan pribadi.');
/*!40000 ALTER TABLE `tb_layanan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_pengguna`
--

DROP TABLE IF EXISTS `tb_pengguna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_pengguna` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengguna` int(11) NOT NULL,
  `username` varchar(222) NOT NULL,
  `nama` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `foto` varchar(222) NOT NULL DEFAULT 'default.png',
  `role` varchar(222) NOT NULL,
  `waktu_buat` varchar(222) DEFAULT NULL,
  `waktu_update` varchar(222) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_pengguna` (`id_pengguna`)
) ENGINE=InnoDB AUTO_INCREMENT=911668 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pengguna`
--

LOCK TABLES `tb_pengguna` WRITE;
/*!40000 ALTER TABLE `tb_pengguna` DISABLE KEYS */;
INSERT INTO `tb_pengguna` VALUES (911667,9917,'admin','Fadilah Riczky','21232f297a57a5a743894a0e4a801fc3','friczky@gmail.com','PAS_FOTO_(2)_-_Copy2.jpg','0',NULL,NULL);
/*!40000 ALTER TABLE `tb_pengguna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_sistem`
--

DROP TABLE IF EXISTS `tb_sistem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_sistem` (
  `id_sistem` int(11) NOT NULL AUTO_INCREMENT,
  `nama_web` varchar(222) NOT NULL,
  `tentang` text NOT NULL,
  `telpon` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `instagram` varchar(222) NOT NULL,
  `facebook` varchar(222) NOT NULL,
  `youtube` varchar(222) NOT NULL,
  `maps` text NOT NULL,
  `logo` varchar(222) NOT NULL,
  PRIMARY KEY (`id_sistem`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_sistem`
--

LOCK TABLES `tb_sistem` WRITE;
/*!40000 ALTER TABLE `tb_sistem` DISABLE KEYS */;
INSERT INTO `tb_sistem` VALUES (1,'Yayasan Rumah Mandiri Yogyakarta','Yayasan Rumah Mandiri Yogyakarta<br>','08967881528','yayasanrumahmandiri@gmail.com','instagram','facebook','youtube','Yayasan Rumah Mandiri Yogyakarta','logo-yayasan-rumy1.png');
/*!40000 ALTER TABLE `tb_sistem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_slider`
--

DROP TABLE IF EXISTS `tb_slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foto` varchar(222) NOT NULL,
  `judul` varchar(222) NOT NULL,
  `deskripsi` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_slider`
--

LOCK TABLES `tb_slider` WRITE;
/*!40000 ALTER TABLE `tb_slider` DISABLE KEYS */;
INSERT INTO `tb_slider` VALUES (1,'slider-11.jpg','Bantuan CIanjur','Mari Membantu Cianjur Mari Membantu Cianjur Mari Membantu Cianjur Mari Membantu Cianjur'),(2,'slider-2.jpg','Bantuan CIanjur Part 2','Bantuan CIanjur Part 2 Bantuan CIanjur Part 2 Bantuan CIanjur Part 2');
/*!40000 ALTER TABLE `tb_slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_sosmed`
--

DROP TABLE IF EXISTS `tb_sosmed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_sosmed` (
  `id_sosmed` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengguna` int(11) DEFAULT NULL,
  `id_ustadz` int(11) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_sosmed`),
  KEY `id_pengguna` (`id_pengguna`),
  KEY `id_ustadz` (`id_ustadz`),
  CONSTRAINT `tb_sosmed_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `tb_pengguna` (`id_pengguna`) ON DELETE CASCADE,
  CONSTRAINT `tb_sosmed_ibfk_2` FOREIGN KEY (`id_ustadz`) REFERENCES `tb_ustadz` (`id_ustadz`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_sosmed`
--

LOCK TABLES `tb_sosmed` WRITE;
/*!40000 ALTER TABLE `tb_sosmed` DISABLE KEYS */;
INSERT INTO `tb_sosmed` VALUES (1,NULL,1,NULL,NULL,NULL),(2,NULL,2,NULL,NULL,NULL),(3,NULL,3,NULL,NULL,NULL),(4,NULL,4,NULL,NULL,NULL),(5,NULL,5,'juher','juher','juher'),(6,NULL,6,'syatori','syatori','syatori'),(7,NULL,777,'','Fadilah Riczky',''),(8,NULL,341,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tb_sosmed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_ustadz`
--

DROP TABLE IF EXISTS `tb_ustadz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_ustadz` (
  `id_ustadz` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(222) NOT NULL,
  `telpon` varchar(222) NOT NULL,
  `alamat` text NOT NULL,
  `foto` varchar(222) DEFAULT NULL,
  `waktu_buat` varchar(222) NOT NULL,
  `waktu_update` varchar(222) NOT NULL,
  PRIMARY KEY (`id_ustadz`)
) ENGINE=InnoDB AUTO_INCREMENT=778 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_ustadz`
--

LOCK TABLES `tb_ustadz` WRITE;
/*!40000 ALTER TABLE `tb_ustadz` DISABLE KEYS */;
INSERT INTO `tb_ustadz` VALUES (1,'Ustadz Andi Alief','08976455151','Purwokerto','Screenshot_201.png','2022-02-03 17:20:52','2022-04-06 01:26:32'),(2,'Ustadz Tulus Mustofa','0000011','Jogja','Screenshot_20.png','2022-02-04 00:21:46','2022-08-20 18:59:56'),(3,'Ustadz Deden','0000','Jogja','Screenshot_202.png','2022-04-06 01:26:59',''),(4,'Ustadz Fahmi Aziz','08967881528','Jogja',NULL,'2022-04-06 01:32:12','2022-04-06 01:34:52'),(5,'Ustadz Juher','08967881528','Jogja','Screenshot_203.png','2022-04-06 01:34:32','2022-04-06 01:35:04'),(6,'Ustadz Syatori','08967881528','Jogja',NULL,'2022-04-06 01:35:50',''),(341,'Alfin','+6289673881528','Desa Air Asam Kec.Lubai Kab.Muara Enim',NULL,'2022-08-27 03:53:48',''),(777,'Fadilah Riczky','+6289673881528','Desa Air Asam Kec.Lubai Kab.Muara Enim',NULL,'2022-08-27 03:52:59','');
/*!40000 ALTER TABLE `tb_ustadz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zakat'
--

--
-- Dumping routines for database 'zakat'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-07 20:52:22
